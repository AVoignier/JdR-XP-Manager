﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.ClassesDonnées;
using WindowsFormsApp1.Données;

namespace WindowsFormsApp1
{
    public partial class FenPersonnages : Form
    {
        private LectureDonnées lectureDonnees;
        private EcritureDonnées ecritureDonnees;
        private SuppressionDonnées suppressionDonnees;
        private ModificationDonnées modificationDonnees;

        private List<Equipe> equipes;
        private List<Personnage> personnages;

        public FenPersonnages()
        {
            InitializeComponent();

            lectureDonnees = LectureDonnées.GetInstance();
            ecritureDonnees = EcritureDonnées.GetInstance();
            suppressionDonnees = SuppressionDonnées.GetInstance();
            modificationDonnees = ModificationDonnées.GetInstance();

            equipes = new List<Equipe>();
            personnages = new List<Personnage>();

            MajEquipes();
            MajPersonnages();
        }

        private void MajEquipes()
        {
            equipes.Clear();
            equipes = lectureDonnees.GetEquipes();

            MajCmbEquipes();
        }

        private void MajCmbEquipes()
        {
            cmbEquipe.Items.Clear();

            ListViewItem item;
            foreach (Equipe equipe in equipes)
            {
                item = new ListViewItem(equipe.ToString());
                cmbEquipe.Items.Add(item.Text);
            }
        }

        private void MajPersonnages()
        {
            if (cmbEquipe.SelectedIndex == -1)
            {
                personnages.Clear();
                personnages = lectureDonnees.GetPersonnages(rdbMortNon.Checked);
                MajLstPersonnages();
            }
            else
            {
                personnages.Clear();
                personnages = lectureDonnees.GetPersonnagesParEquipe(equipes[cmbEquipe.SelectedIndex], rdbMortNon.Checked);
                MajLstPersonnages();
            }


        }

        private void MajLstPersonnages()
        {
            lstPersonnages.Items.Clear();

            ListViewItem item;
            foreach (Personnage personnage in personnages)
            {
                item = new ListViewItem(personnage.GetNom());
                item.SubItems.Add( personnage.GetNiveau().ToString());
                item.SubItems.Add( personnage.GetExperience().ToString() );

                if(!personnage.GetVivant())
                {
                    item.ForeColor = Color.Red;
                }

                lstPersonnages.Items.Add(item);
            }
        }

        private void cmbEquipe_SelectedIndexChanged(object sender, EventArgs e)
        {
            MajPersonnages();
        }

        private void rdbMortNon_CheckedChanged(object sender, EventArgs e)
        {
            MajPersonnages();
        }

        private void rdbMortOui_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lstPersonnages_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstPersonnages.SelectedItems.Count == 0)
            {
                btnModifier.Enabled = false;
            }
            else
            {
                btnModifier.Enabled = true;
            }
        }
    }
}
