﻿namespace WindowsFormsApp1
{
    partial class FenEquipes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstEquipe = new System.Windows.Forms.ListView();
            this.NomEquipe = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstJoueurs = new System.Windows.Forms.ListView();
            this.NomJoueur = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstPersonnages = new System.Windows.Forms.ListView();
            this.NomPersonnage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NiveauJoueur = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Experience = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblEquipes = new System.Windows.Forms.Label();
            this.lblJoueur = new System.Windows.Forms.Label();
            this.lblPersonnages = new System.Windows.Forms.Label();
            this.btnCreerEquipe = new System.Windows.Forms.Button();
            this.btnModifierEquipe = new System.Windows.Forms.Button();
            this.btnAfficherToutLesJoueurs = new System.Windows.Forms.Button();
            this.grbAffichagePersonnagesMorts = new System.Windows.Forms.GroupBox();
            this.rdbMortNon = new System.Windows.Forms.RadioButton();
            this.rdbMortOui = new System.Windows.Forms.RadioButton();
            this.grbAffichagePersonnagesMorts.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstEquipe
            // 
            this.lstEquipe.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NomEquipe});
            this.lstEquipe.FullRowSelect = true;
            this.lstEquipe.HideSelection = false;
            this.lstEquipe.Location = new System.Drawing.Point(12, 29);
            this.lstEquipe.MultiSelect = false;
            this.lstEquipe.Name = "lstEquipe";
            this.lstEquipe.Size = new System.Drawing.Size(186, 263);
            this.lstEquipe.TabIndex = 0;
            this.lstEquipe.UseCompatibleStateImageBehavior = false;
            this.lstEquipe.View = System.Windows.Forms.View.Details;
            this.lstEquipe.SelectedIndexChanged += new System.EventHandler(this.lstEquipe_SelectedIndexChanged);
            // 
            // NomEquipe
            // 
            this.NomEquipe.Text = "Nom";
            this.NomEquipe.Width = 164;
            // 
            // lstJoueurs
            // 
            this.lstJoueurs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NomJoueur});
            this.lstJoueurs.HideSelection = false;
            this.lstJoueurs.Location = new System.Drawing.Point(204, 29);
            this.lstJoueurs.MultiSelect = false;
            this.lstJoueurs.Name = "lstJoueurs";
            this.lstJoueurs.Size = new System.Drawing.Size(186, 263);
            this.lstJoueurs.TabIndex = 1;
            this.lstJoueurs.UseCompatibleStateImageBehavior = false;
            this.lstJoueurs.View = System.Windows.Forms.View.Details;
            this.lstJoueurs.SelectedIndexChanged += new System.EventHandler(this.lstJoueurs_SelectedIndexChanged);
            // 
            // NomJoueur
            // 
            this.NomJoueur.Text = "Nom";
            this.NomJoueur.Width = 145;
            // 
            // lstPersonnages
            // 
            this.lstPersonnages.AutoArrange = false;
            this.lstPersonnages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NomPersonnage,
            this.NiveauJoueur,
            this.Experience});
            this.lstPersonnages.HideSelection = false;
            this.lstPersonnages.Location = new System.Drawing.Point(396, 29);
            this.lstPersonnages.MultiSelect = false;
            this.lstPersonnages.Name = "lstPersonnages";
            this.lstPersonnages.Size = new System.Drawing.Size(340, 263);
            this.lstPersonnages.TabIndex = 2;
            this.lstPersonnages.UseCompatibleStateImageBehavior = false;
            this.lstPersonnages.View = System.Windows.Forms.View.Details;
            this.lstPersonnages.SelectedIndexChanged += new System.EventHandler(this.lstPersonnages_SelectedIndexChanged);
            // 
            // NomPersonnage
            // 
            this.NomPersonnage.Text = "Nom";
            this.NomPersonnage.Width = 218;
            // 
            // NiveauJoueur
            // 
            this.NiveauJoueur.Text = "Niveau";
            this.NiveauJoueur.Width = 50;
            // 
            // Experience
            // 
            this.Experience.Text = "Expérience";
            this.Experience.Width = 66;
            // 
            // lblEquipes
            // 
            this.lblEquipes.AutoSize = true;
            this.lblEquipes.Location = new System.Drawing.Point(13, 13);
            this.lblEquipes.Name = "lblEquipes";
            this.lblEquipes.Size = new System.Drawing.Size(45, 13);
            this.lblEquipes.TabIndex = 3;
            this.lblEquipes.Text = "Equipes";
            // 
            // lblJoueur
            // 
            this.lblJoueur.AutoSize = true;
            this.lblJoueur.Location = new System.Drawing.Point(204, 12);
            this.lblJoueur.Name = "lblJoueur";
            this.lblJoueur.Size = new System.Drawing.Size(44, 13);
            this.lblJoueur.TabIndex = 4;
            this.lblJoueur.Text = "Joueurs";
            // 
            // lblPersonnages
            // 
            this.lblPersonnages.AutoSize = true;
            this.lblPersonnages.Location = new System.Drawing.Point(396, 11);
            this.lblPersonnages.Name = "lblPersonnages";
            this.lblPersonnages.Size = new System.Drawing.Size(69, 13);
            this.lblPersonnages.TabIndex = 5;
            this.lblPersonnages.Text = "Personnages";
            // 
            // btnCreerEquipe
            // 
            this.btnCreerEquipe.Location = new System.Drawing.Point(12, 298);
            this.btnCreerEquipe.Name = "btnCreerEquipe";
            this.btnCreerEquipe.Size = new System.Drawing.Size(186, 30);
            this.btnCreerEquipe.TabIndex = 6;
            this.btnCreerEquipe.Text = "Créer Equipe";
            this.btnCreerEquipe.UseVisualStyleBackColor = true;
            this.btnCreerEquipe.Click += new System.EventHandler(this.btnCreerEquipe_Click);
            // 
            // btnModifierEquipe
            // 
            this.btnModifierEquipe.Location = new System.Drawing.Point(12, 334);
            this.btnModifierEquipe.Name = "btnModifierEquipe";
            this.btnModifierEquipe.Size = new System.Drawing.Size(186, 30);
            this.btnModifierEquipe.TabIndex = 7;
            this.btnModifierEquipe.Text = "Modifier Equipe";
            this.btnModifierEquipe.UseVisualStyleBackColor = true;
            this.btnModifierEquipe.Click += new System.EventHandler(this.btnModifierEquipe_Click);
            // 
            // btnAfficherToutLesJoueurs
            // 
            this.btnAfficherToutLesJoueurs.Location = new System.Drawing.Point(204, 298);
            this.btnAfficherToutLesJoueurs.Name = "btnAfficherToutLesJoueurs";
            this.btnAfficherToutLesJoueurs.Size = new System.Drawing.Size(186, 30);
            this.btnAfficherToutLesJoueurs.TabIndex = 8;
            this.btnAfficherToutLesJoueurs.Text = "Afficher tout les joueurs";
            this.btnAfficherToutLesJoueurs.UseVisualStyleBackColor = true;
            this.btnAfficherToutLesJoueurs.Click += new System.EventHandler(this.btnAfficherToutLesJoueurs_Click);
            // 
            // grbAffichagePersonnagesMorts
            // 
            this.grbAffichagePersonnagesMorts.Controls.Add(this.rdbMortNon);
            this.grbAffichagePersonnagesMorts.Controls.Add(this.rdbMortOui);
            this.grbAffichagePersonnagesMorts.Location = new System.Drawing.Point(399, 299);
            this.grbAffichagePersonnagesMorts.Name = "grbAffichagePersonnagesMorts";
            this.grbAffichagePersonnagesMorts.Size = new System.Drawing.Size(163, 43);
            this.grbAffichagePersonnagesMorts.TabIndex = 9;
            this.grbAffichagePersonnagesMorts.TabStop = false;
            this.grbAffichagePersonnagesMorts.Text = "Affichage Personnages Morts";
            // 
            // rdbMortNon
            // 
            this.rdbMortNon.AutoSize = true;
            this.rdbMortNon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.rdbMortNon.Checked = true;
            this.rdbMortNon.Location = new System.Drawing.Point(54, 19);
            this.rdbMortNon.Name = "rdbMortNon";
            this.rdbMortNon.Size = new System.Drawing.Size(45, 17);
            this.rdbMortNon.TabIndex = 1;
            this.rdbMortNon.TabStop = true;
            this.rdbMortNon.Text = "Non";
            this.rdbMortNon.UseVisualStyleBackColor = true;
            this.rdbMortNon.CheckedChanged += new System.EventHandler(this.rdbMortNon_CheckedChanged);
            // 
            // rdbMortOui
            // 
            this.rdbMortOui.AutoSize = true;
            this.rdbMortOui.Location = new System.Drawing.Point(7, 20);
            this.rdbMortOui.Name = "rdbMortOui";
            this.rdbMortOui.Size = new System.Drawing.Size(41, 17);
            this.rdbMortOui.TabIndex = 0;
            this.rdbMortOui.Text = "Oui";
            this.rdbMortOui.UseVisualStyleBackColor = true;
            // 
            // FenEquipes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 370);
            this.Controls.Add(this.grbAffichagePersonnagesMorts);
            this.Controls.Add(this.btnAfficherToutLesJoueurs);
            this.Controls.Add(this.btnModifierEquipe);
            this.Controls.Add(this.btnCreerEquipe);
            this.Controls.Add(this.lblPersonnages);
            this.Controls.Add(this.lblJoueur);
            this.Controls.Add(this.lblEquipes);
            this.Controls.Add(this.lstPersonnages);
            this.Controls.Add(this.lstJoueurs);
            this.Controls.Add(this.lstEquipe);
            this.Name = "FenEquipes";
            this.Text = "Equipe";
            this.Load += new System.EventHandler(this.FenEquipe_Load);
            this.grbAffichagePersonnagesMorts.ResumeLayout(false);
            this.grbAffichagePersonnagesMorts.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstEquipe;
        private System.Windows.Forms.ListView lstJoueurs;
        private System.Windows.Forms.ListView lstPersonnages;
        private System.Windows.Forms.Label lblEquipes;
        private System.Windows.Forms.Label lblJoueur;
        private System.Windows.Forms.Label lblPersonnages;
        private System.Windows.Forms.Button btnCreerEquipe;
        private System.Windows.Forms.Button btnModifierEquipe;
        private System.Windows.Forms.Button btnAfficherToutLesJoueurs;
        private System.Windows.Forms.ColumnHeader NomEquipe;
        private System.Windows.Forms.ColumnHeader NomJoueur;
        private System.Windows.Forms.ColumnHeader NomPersonnage;
        private System.Windows.Forms.ColumnHeader NiveauJoueur;
        private System.Windows.Forms.ColumnHeader Experience;
        private System.Windows.Forms.GroupBox grbAffichagePersonnagesMorts;
        private System.Windows.Forms.RadioButton rdbMortNon;
        private System.Windows.Forms.RadioButton rdbMortOui;
    }
}