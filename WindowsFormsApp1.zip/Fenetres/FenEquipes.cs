﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.ClassesDonnées;

namespace WindowsFormsApp1
{
    public partial class FenEquipes : Form
    {
        private LectureDonnées donnees;

        private List<Equipe> equipes;
        private List<Joueur> joueurs;
        private List<Personnage> personnages;

        public FenEquipes()
        {
            InitializeComponent();

            donnees = LectureDonnées.GetInstance();

            equipes = new List<Equipe>();
            joueurs = new List<Joueur>();
            personnages = new List<Personnage>();

            MajLstEquipes();
            MajLstJoueurs();
            MajLstPersonnages();

        }

        private void MajLstEquipes()
        {
            lstEquipe.Items.Clear();
            equipes.Clear();
            equipes = donnees.GetEquipes();

            ListViewItem item;

            foreach (Equipe equipe in equipes)
            {
                item = new ListViewItem(equipe.GetNom());
                lstEquipe.Items.Add(item.Text);
            }

        }

        private void MajLstJoueurs()
        {
            lstJoueurs.Items.Clear();
            joueurs.Clear();
            joueurs = donnees.GetJoueurs();

            ListViewItem item;

            foreach (Joueur joueur in joueurs)
            {
                item = new ListViewItem(joueur.GetNom());
                lstJoueurs.Items.Add(item.Text);
            }

        }

        private void MajLstJoueursEquipeSelectionnée()
        {
            lstJoueurs.Items.Clear();
            joueurs.Clear();
            joueurs = donnees.GetJoueursParEquipe(equipes[lstEquipe.SelectedIndices[0]]);

            ListViewItem item;

            foreach (Joueur joueur in joueurs)
            {
                item = new ListViewItem(joueur.GetNom());

                lstJoueurs.Items.Add(item);
            }
        }

        private void MajLstPersonnages()
        {
            lstPersonnages.Items.Clear();
            personnages.Clear();
            personnages = donnees.GetPersonnages(rdbMortNon.Checked);

            ListViewItem item;

            foreach (Personnage personnage in personnages)
            {
                item = new ListViewItem(personnage.GetNom());
                item.SubItems.Add( personnage.GetNiveau().ToString() );
                item.SubItems.Add(personnage.GetExperience().ToString());

                if(!personnage.GetVivant())
                    item.ForeColor = Color.Red;

                lstPersonnages.Items.Add(item);
            }
        }

        private void MajLstPersonnagesEquipeSelectionnée()
        {
            lstPersonnages.Items.Clear();
            personnages.Clear();
            personnages = donnees.GetPersonnagesParEquipe(equipes[lstEquipe.SelectedIndices[0]], rdbMortNon.Checked);

            ListViewItem item;

            foreach (Personnage personnage in personnages)
            {
                item = new ListViewItem(personnage.GetNom());
                item.SubItems.Add(personnage.GetNiveau().ToString());
                item.SubItems.Add(personnage.GetExperience().ToString());

                if (!personnage.GetVivant())
                    item.ForeColor = Color.Red;

                lstPersonnages.Items.Add(item);
            }
        }

        private void btnCreerEquipe_Click(object sender, EventArgs e)
        {
            FenEquipeParam fenEquipeParam = new FenEquipeParam(0);
            fenEquipeParam.Show();            
        }

        private void btnAfficherToutLesJoueurs_Click(object sender, EventArgs e)
        {

        }

        private void btnModifierEquipe_Click(object sender, EventArgs e)
        {
            FenEquipeParam fenEquipeParam = new FenEquipeParam(equipes[lstEquipe.SelectedIndices[0]].GetId());
            fenEquipeParam.Show();
        }

        private void FenEquipe_Load(object sender, EventArgs e)
        {

        }

        private void rdbMortNon_CheckedChanged(object sender, EventArgs e)
        {
            if (lstEquipe.SelectedItems.Count == 0)
            {
                MajLstJoueurs();
                MajLstPersonnages();
            }
            else if (lstEquipe.SelectedItems.Count == 1)
            {
                MajLstJoueursEquipeSelectionnée();
                MajLstPersonnagesEquipeSelectionnée();
            }
        }

        private void lstEquipe_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstEquipe.SelectedItems.Count == 0)
            {
                MajLstJoueurs();
                MajLstPersonnages();
            }
            else if(lstEquipe.SelectedItems.Count == 1)
            {
                MajLstJoueursEquipeSelectionnée();
                MajLstPersonnagesEquipeSelectionnée();
            }
        }

        private void lstJoueurs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstPersonnages_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
