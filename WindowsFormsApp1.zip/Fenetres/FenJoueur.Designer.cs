﻿namespace WindowsFormsApp1
{
    partial class FenJoueur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstJoueurs = new System.Windows.Forms.ListView();
            this.Nom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnNouveauJoueur = new System.Windows.Forms.Button();
            this.txbNomJoueur = new System.Windows.Forms.TextBox();
            this.lblNomJoueur = new System.Windows.Forms.Label();
            this.btnAjouterModifier = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnModifierJoueur = new System.Windows.Forms.Button();
            this.lstPersonnages = new System.Windows.Forms.ListView();
            this.Personnage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Niveau = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Xp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSupprimerJoueur = new System.Windows.Forms.Button();
            this.grbAfficherMorts = new System.Windows.Forms.GroupBox();
            this.rdbNon = new System.Windows.Forms.RadioButton();
            this.rdbOui = new System.Windows.Forms.RadioButton();
            this.grbAfficherMorts.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstJoueurs
            // 
            this.lstJoueurs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Nom});
            this.lstJoueurs.FullRowSelect = true;
            this.lstJoueurs.HideSelection = false;
            this.lstJoueurs.Location = new System.Drawing.Point(13, 13);
            this.lstJoueurs.MultiSelect = false;
            this.lstJoueurs.Name = "lstJoueurs";
            this.lstJoueurs.Size = new System.Drawing.Size(152, 265);
            this.lstJoueurs.TabIndex = 0;
            this.lstJoueurs.UseCompatibleStateImageBehavior = false;
            this.lstJoueurs.View = System.Windows.Forms.View.Details;
            this.lstJoueurs.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lstJoueurs_ItemSelectionChanged);
            // 
            // Nom
            // 
            this.Nom.Text = "Nom";
            this.Nom.Width = 83;
            // 
            // btnNouveauJoueur
            // 
            this.btnNouveauJoueur.Location = new System.Drawing.Point(13, 284);
            this.btnNouveauJoueur.Name = "btnNouveauJoueur";
            this.btnNouveauJoueur.Size = new System.Drawing.Size(117, 23);
            this.btnNouveauJoueur.TabIndex = 1;
            this.btnNouveauJoueur.Text = "Nouveau Joueur";
            this.btnNouveauJoueur.UseVisualStyleBackColor = true;
            this.btnNouveauJoueur.Click += new System.EventHandler(this.btnNouveauJoueur_Click);
            // 
            // txbNomJoueur
            // 
            this.txbNomJoueur.Location = new System.Drawing.Point(133, 311);
            this.txbNomJoueur.Name = "txbNomJoueur";
            this.txbNomJoueur.Size = new System.Drawing.Size(117, 20);
            this.txbNomJoueur.TabIndex = 2;
            this.txbNomJoueur.Visible = false;
            // 
            // lblNomJoueur
            // 
            this.lblNomJoueur.AutoSize = true;
            this.lblNomJoueur.Location = new System.Drawing.Point(13, 314);
            this.lblNomJoueur.Name = "lblNomJoueur";
            this.lblNomJoueur.Size = new System.Drawing.Size(70, 13);
            this.lblNomJoueur.TabIndex = 3;
            this.lblNomJoueur.Text = "Nom Joueur :";
            this.lblNomJoueur.Visible = false;
            // 
            // btnAjouterModifier
            // 
            this.btnAjouterModifier.Location = new System.Drawing.Point(16, 337);
            this.btnAjouterModifier.Name = "btnAjouterModifier";
            this.btnAjouterModifier.Size = new System.Drawing.Size(114, 23);
            this.btnAjouterModifier.TabIndex = 4;
            this.btnAjouterModifier.Text = "Ajouter/Modifier";
            this.btnAjouterModifier.UseVisualStyleBackColor = true;
            this.btnAjouterModifier.Visible = false;
            this.btnAjouterModifier.Click += new System.EventHandler(this.btnAjouterModifier_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(136, 337);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(114, 23);
            this.btnAnnuler.TabIndex = 5;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Visible = false;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // btnModifierJoueur
            // 
            this.btnModifierJoueur.Location = new System.Drawing.Point(136, 284);
            this.btnModifierJoueur.Name = "btnModifierJoueur";
            this.btnModifierJoueur.Size = new System.Drawing.Size(117, 23);
            this.btnModifierJoueur.TabIndex = 6;
            this.btnModifierJoueur.Text = "Modifier Joueur";
            this.btnModifierJoueur.UseVisualStyleBackColor = true;
            this.btnModifierJoueur.Click += new System.EventHandler(this.btnModifierJoueur_Click);
            // 
            // lstPersonnages
            // 
            this.lstPersonnages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Personnage,
            this.Niveau,
            this.Xp});
            this.lstPersonnages.Enabled = false;
            this.lstPersonnages.FullRowSelect = true;
            this.lstPersonnages.HideSelection = false;
            this.lstPersonnages.Location = new System.Drawing.Point(171, 13);
            this.lstPersonnages.MultiSelect = false;
            this.lstPersonnages.Name = "lstPersonnages";
            this.lstPersonnages.Size = new System.Drawing.Size(401, 265);
            this.lstPersonnages.TabIndex = 11;
            this.lstPersonnages.UseCompatibleStateImageBehavior = false;
            this.lstPersonnages.View = System.Windows.Forms.View.Details;
            // 
            // Personnage
            // 
            this.Personnage.Text = "Personnage";
            this.Personnage.Width = 108;
            // 
            // Niveau
            // 
            this.Niveau.Text = "Niveau";
            this.Niveau.Width = 51;
            // 
            // Xp
            // 
            this.Xp.Text = "Expérience";
            this.Xp.Width = 94;
            // 
            // btnSupprimerJoueur
            // 
            this.btnSupprimerJoueur.Location = new System.Drawing.Point(259, 284);
            this.btnSupprimerJoueur.Name = "btnSupprimerJoueur";
            this.btnSupprimerJoueur.Size = new System.Drawing.Size(117, 23);
            this.btnSupprimerJoueur.TabIndex = 12;
            this.btnSupprimerJoueur.Text = "Supprimer Joueur";
            this.btnSupprimerJoueur.UseVisualStyleBackColor = true;
            this.btnSupprimerJoueur.Click += new System.EventHandler(this.btnSupprimerJoueur_Click);
            // 
            // grbAfficherMorts
            // 
            this.grbAfficherMorts.Controls.Add(this.rdbNon);
            this.grbAfficherMorts.Controls.Add(this.rdbOui);
            this.grbAfficherMorts.Location = new System.Drawing.Point(383, 284);
            this.grbAfficherMorts.Name = "grbAfficherMorts";
            this.grbAfficherMorts.Size = new System.Drawing.Size(190, 43);
            this.grbAfficherMorts.TabIndex = 13;
            this.grbAfficherMorts.TabStop = false;
            this.grbAfficherMorts.Text = "Afficher Personnages Morts";
            // 
            // rdbNon
            // 
            this.rdbNon.AutoSize = true;
            this.rdbNon.Checked = true;
            this.rdbNon.Location = new System.Drawing.Point(54, 19);
            this.rdbNon.Name = "rdbNon";
            this.rdbNon.Size = new System.Drawing.Size(45, 17);
            this.rdbNon.TabIndex = 1;
            this.rdbNon.TabStop = true;
            this.rdbNon.Text = "Non";
            this.rdbNon.UseVisualStyleBackColor = true;
            this.rdbNon.CheckedChanged += new System.EventHandler(this.rdbNon_CheckedChanged);
            // 
            // rdbOui
            // 
            this.rdbOui.AutoSize = true;
            this.rdbOui.Location = new System.Drawing.Point(7, 20);
            this.rdbOui.Name = "rdbOui";
            this.rdbOui.Size = new System.Drawing.Size(41, 17);
            this.rdbOui.TabIndex = 0;
            this.rdbOui.Text = "Oui";
            this.rdbOui.UseVisualStyleBackColor = true;
            // 
            // FenJoueur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 367);
            this.Controls.Add(this.grbAfficherMorts);
            this.Controls.Add(this.btnSupprimerJoueur);
            this.Controls.Add(this.lstPersonnages);
            this.Controls.Add(this.btnModifierJoueur);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnAjouterModifier);
            this.Controls.Add(this.lblNomJoueur);
            this.Controls.Add(this.txbNomJoueur);
            this.Controls.Add(this.btnNouveauJoueur);
            this.Controls.Add(this.lstJoueurs);
            this.Name = "FenJoueur";
            this.Text = "FenJoueur";
            this.grbAfficherMorts.ResumeLayout(false);
            this.grbAfficherMorts.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstJoueurs;
        private System.Windows.Forms.ColumnHeader Nom;
        private System.Windows.Forms.Button btnNouveauJoueur;
        private System.Windows.Forms.TextBox txbNomJoueur;
        private System.Windows.Forms.Label lblNomJoueur;
        private System.Windows.Forms.Button btnAjouterModifier;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnModifierJoueur;
        private System.Windows.Forms.ListView lstPersonnages;
        private System.Windows.Forms.ColumnHeader Personnage;
        private System.Windows.Forms.Button btnSupprimerJoueur;
        private System.Windows.Forms.GroupBox grbAfficherMorts;
        private System.Windows.Forms.RadioButton rdbNon;
        private System.Windows.Forms.RadioButton rdbOui;
        private System.Windows.Forms.ColumnHeader Niveau;
        private System.Windows.Forms.ColumnHeader Xp;
    }
}