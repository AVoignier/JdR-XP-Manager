﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.ClassesDonnées;
using WindowsFormsApp1.Données;

namespace WindowsFormsApp1
{
    public partial class FenJoueur : Form
    {
        private LectureDonnées lectureDonnees;
        private EcritureDonnées ecritureDonnees;
        private SuppressionDonnées suppressionDonnees;
        private ModificationDonnées modificationDonnees;

        private List<Joueur> joueurs;
        private List<Personnage> personnages;

        private int menuMode;
            // 0 -> Menu par defaut
            // 1 -> Création perso
            // 2 -> Modification perso

        public FenJoueur()
        {
            InitializeComponent();

            lectureDonnees = LectureDonnées.GetInstance();
            ecritureDonnees = EcritureDonnées.GetInstance();
            suppressionDonnees = SuppressionDonnées.GetInstance();
            modificationDonnees = ModificationDonnées.GetInstance();
            

            joueurs = lectureDonnees.GetJoueurs();
            personnages = new List<Personnage>();

            menuMode = 0;

            AffichageMenuMode();

            MajLstJoueurs();
            MajLstPersonnages();

        }

        private void AffichageMenuMode()
        {
            if(menuMode == 0) // Mode par defaut
            {
                lblNomJoueur.Visible = false;
                txbNomJoueur.Visible = false;
                btnAjouterModifier.Visible = false;
                btnAnnuler.Visible = false;

                lstJoueurs.Enabled = true;
                lstPersonnages.Enabled = true;
            }
            else if(menuMode == 1) // Mode Création Personnage
            {
                lblNomJoueur.Text = " Nom Joueur : ";
                btnAjouterModifier.Text = "Ajouter";

                lblNomJoueur.Visible = true;
                txbNomJoueur.Visible = true;
                btnAjouterModifier.Visible = true;
                btnAnnuler.Visible = true;

                lstJoueurs.Enabled = false;
                lstPersonnages.Enabled = false;
            }
            else if (menuMode == 2) // Mode Modification Personnage
            {
                lblNomJoueur.Text = " Nouveau Nom : ";
                btnAjouterModifier.Text = "Modifier";

                lblNomJoueur.Visible = true;
                txbNomJoueur.Visible = true;
                btnAjouterModifier.Visible = true;
                btnAnnuler.Visible = true;

                txbNomJoueur.Text = joueurs[lstJoueurs.SelectedIndices[0]].GetNom();
            }
        }

        private void MajJoueurs()
        {
            joueurs.Clear();
            joueurs = lectureDonnees.GetJoueurs();

            MajLstJoueurs();
        }

        private void MajPersonnages()
        {
            if( lstJoueurs.SelectedIndices.Count == 0 )
            {
                personnages.Clear();
                lstPersonnages.Items.Clear();

            }
            else
            {
                personnages.Clear();
                personnages = lectureDonnees.GetPersonnagesParJoueur(joueurs[lstJoueurs.SelectedIndices[0] ],rdbNon.Checked );
                MajLstPersonnages();
            }
            
        }

        private void MajLstJoueurs()
        {
            lstJoueurs.Items.Clear();

            ListViewItem item;
            foreach (Joueur joueur in joueurs)
            {
                item = new ListViewItem(joueur.ToString());
                lstJoueurs.Items.Add(item);
            }

        }

        private void MajLstPersonnages()
        {
            lstPersonnages.Items.Clear();

            ListViewItem item;

            foreach( Personnage personnage in personnages )
            {
                item = new ListViewItem(personnage.GetNom());
                item.SubItems.Add( personnage.GetNiveau().ToString());
                item.SubItems.Add( personnage.GetExperience().ToString());
                
                if (!personnage.GetVivant())
                {
                    item.ForeColor = Color.Red;
                }

                lstPersonnages.Items.Add(item);
            }

        }

        private void btnNouveauJoueur_Click(object sender, EventArgs e)
        {
            menuMode = 1;
            AffichageMenuMode();
        }

        private void btnModifierJoueur_Click(object sender, EventArgs e)
        {
            if (lstJoueurs.SelectedIndices.Count == 0)
            {
                string msg = "Vous devez selectionner un joueur";
                MessageBox.Show(msg, "Modification Joueur", MessageBoxButtons.OK);
            }
            else
            {
                menuMode = 2;
                AffichageMenuMode();
                
            }

            
        }

        private void btnSupprimerJoueur_Click(object sender, EventArgs e)
        {
            if( lstJoueurs.SelectedIndices.Count == 0)
            {
                string msg = "Vous devez selectionner un joueur";
                MessageBox.Show(msg, "Supprimer Joueur", MessageBoxButtons.OK);
            }
            else
            {
                string msg = "Etes vous sur de vouloir supprimer le joueur " + joueurs[ lstJoueurs.SelectedIndices[0] ].GetNom() + " ? Cela supprimera également tout ses personnages";
                if (MessageBox.Show(msg, "Ajouter Joueur", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    suppressionDonnees.SupprimerJoueur(joueurs[lstJoueurs.SelectedIndices[0]]);
                    MajJoueurs();
                }  
            }
            
        }

        private void btnAjouterModifier_Click(object sender, EventArgs e)
        {
            //Mode Création Joueur
            if( menuMode == 1)
            {
                if (VérificationEcritureDonnées.VérificationDonnéesJoueur(txbNomJoueur.Text))
                {

                    ecritureDonnees.InsererJoueur( txbNomJoueur.Text );

                    MajJoueurs();

                    menuMode = 0;
                    AffichageMenuMode();
                }
            }
            // Mode Modification Joueur
            else if(menuMode == 2)
            {
                if (VérificationEcritureDonnées.VérificationDonnéesJoueurAvecException(txbNomJoueur.Text, joueurs[lstJoueurs.SelectedIndices[0]]))
                {
                    modificationDonnees.ModificationJoueur(joueurs[lstJoueurs.SelectedIndices[0]], txbNomJoueur.Text);

                    MajJoueurs();

                    menuMode = 0;
                    AffichageMenuMode();


                }
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            menuMode = 0;
            AffichageMenuMode();
            
        }

        private void lstJoueurs_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            personnages.Clear();

            if ( lstJoueurs.SelectedIndices.Count == 0)
            {
                personnages = lectureDonnees.GetPersonnages(rdbNon.Checked);
            }
            else
            {
                personnages = lectureDonnees.GetPersonnagesParJoueur(joueurs[lstJoueurs.SelectedIndices[0]], rdbNon.Checked);
            }

            MajLstPersonnages();


        }

        private void rdbNon_CheckedChanged(object sender, EventArgs e)
        {
            MajPersonnages();
        }
    }
}
