﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.ClassesDonnées;
using WindowsFormsApp1.Données;
using WindowsFormsApp1.Fenetres.FenEquipeParamExt;

namespace WindowsFormsApp1
{
    public partial class FenEquipeParam : Form
    {
        private LectureDonnées lectureDonnees;
        private EcritureDonnées ecritureDonnees;
        private SuppressionDonnées suppressionDonnees;
        private ModificationDonnées modificationDonnees;

        int idLignePJSelectionnée;
        List<LignePJ> lignePJs;

        List<Joueur> joueursGlobal;
        List<Personnage> personnagesGlobal;

        int menuMode;
        // 0 -> ParDefaut
        // 1 -> Création Joueur
        // 2 -> Création Personnage


        int nbPJ;

        public FenEquipeParam(int idEquipe)
        {
            InitializeComponent();

            lectureDonnees = LectureDonnées.GetInstance();
            ecritureDonnees = EcritureDonnées.GetInstance();
            suppressionDonnees = SuppressionDonnées.GetInstance();
            modificationDonnees = ModificationDonnées.GetInstance();

            joueursGlobal = new List<Joueur>();
            personnagesGlobal = new List<Personnage>();
            lignePJs = new List<LignePJ>();

            idLignePJSelectionnée = 0;

            menuMode = 0;
            AffichageMenuMode();

            //Si aucune équipe à été selectionnée
            if(idEquipe == 0)
            {
                InitGrbVide();
            }


        }

        private void AffichageMenuMode()
        {
            if(menuMode == 0)
            {
                // Activation des champs du panel
                foreach (Control control in pnlPJ.Controls)
                {
                    control.Enabled = true;
                }

                btnAjouterPerso.Enabled = true;
                btnValider.Enabled = true;
                btnAnnuler.Enabled = true;

                lblNomJoueur.Visible = false;
                txbNomJoueur.Text = "";
                txbNomJoueur.Visible = false;

                lblNomPersonnage.Visible = false;
                txbNomPersonnage.Text = "";
                txbNomPersonnage.Visible = false;

                lblNiveau.Visible = false;
                nudNiveau.Value = 1;
                nudNiveau.Visible = false;

                lblExpérience.Visible = false;
                txbExpérience.Text = "";
                txbExpérience.Visible = false;

                btnValiderJoueurPerso.Visible = false;
                btnAnnulerJoueurPerso.Visible = false;

                grbAffichageMorts.Enabled = true;
            }
            else if(menuMode == 1)
            {
                // Activation des champs du panel
                foreach (Control control in pnlPJ.Controls)
                {
                    control.Enabled = false;
                }

                btnAjouterPerso.Enabled = false;
                btnValider.Enabled = false;
                btnAnnuler.Enabled = false;

                lblNomJoueur.Visible = true;
                txbNomJoueur.Visible = true;

                lblNomPersonnage.Visible = false;
                txbNomPersonnage.Visible = false;

                nudNiveau.Value = 1;
                lblNiveau.Visible = false;
                nudNiveau.Visible = false;

                lblExpérience.Visible = false;
                txbExpérience.Visible = false;

                btnValiderJoueurPerso.Visible = true;
                btnAnnulerJoueurPerso.Visible = true;

                grbAffichageMorts.Enabled = false;
            }
            else if(menuMode == 2)
            {
                // Activation des champs du panel
                foreach (Control control in pnlPJ.Controls)
                {
                    control.Enabled = false;
                }

                btnAjouterPerso.Enabled = false;
                btnValider.Enabled = false;
                btnAnnuler.Enabled = false;

                lblNomJoueur.Visible = true;
                txbNomJoueur.Visible = true;

                lblNomPersonnage.Visible = true;
                txbNomPersonnage.Visible = true;

                nudNiveau.Value = 1;
                lblNiveau.Visible = true;
                nudNiveau.Visible = true;

                lblExpérience.Visible = true;
                txbExpérience.Visible = true;

                btnValiderJoueurPerso.Visible = true;
                btnAnnulerJoueurPerso.Visible = true;

                grbAffichageMorts.Enabled = false;
            }
        }

        public void ModeCréationJoueur(int idLignePj)
        {
            idLignePJSelectionnée = idLignePj;

            menuMode = 1;
            AffichageMenuMode();
        }

        public void ModeCréationPersonnage(int idLignePj)
        {
            idLignePJSelectionnée = idLignePj;

            menuMode = 2;
            AffichageMenuMode();
        }

        private void InitGrbVide()
        {
            nbPJ = 0;
            AjouterPJ();
        }

        private void AjouterPJ()
        {
            lignePJs.Add(new LignePJ(this, nbPJ, rdbAffichageMortsNon.Checked));
            lignePJs[nbPJ].GetPanel().Location = new Point( 0, pnlPJ.Location.Y + 30*nbPJ - 20 );
            lignePJs[nbPJ].GetPanel().Width = pnlPJ.Width - 20;
            lignePJs[nbPJ].GetPanel().Height = 30;
            pnlPJ.Controls.Add(lignePJs[nbPJ].GetPanel());

            nbPJ++;
        }

        public void BntSupprimerLignePjClick(int idLigne)
        {
            Console.WriteLine("taille : " + lignePJs.Count + " " + nbPJ);
            Console.WriteLine("id : " + idLigne);

            for (int i = nbPJ - 1; i > idLigne; i--)
            {
                Console.WriteLine("i : " + i);
                lignePJs[i].GetPanel().Location = lignePJs[i - 1].GetPanel().Location;
                lignePJs[i].SetId(lignePJs[i - 1].GetIdLigne());
            }

            lignePJs.RemoveAt(idLigne);
            pnlPJ.Controls.RemoveAt(idLigne);
            nbPJ--;

        }

        private void BtnAjouterPerso_Click(object sender, EventArgs e)
        {
            AjouterPJ();
        }

        private void BtnValider_Click(object sender, EventArgs e)
        {

        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RdbAffichageMortsOui_CheckedChanged(object sender, EventArgs e)
        {
            foreach(LignePJ lignePJ in lignePJs)
            {
                lignePJ.SetVivant(rdbAffichageMortsNon.Checked);
            }
        }

        private void btnValiderJoueurPerso_Click(object sender, EventArgs e)
        {
            if(menuMode == 1) // Si en mode création de Joueur
            {
                if ( VérificationEcritureDonnées.VérificationDonnéesJoueur( txbNomJoueur.Text ) )
                {
                    //ecritureDonnees.InsererJoueur( txbNomJoueur.Text );

                    Joueur joueur = new Joueur(-1, txbNomJoueur.Text);
                    lignePJs[idLignePJSelectionnée].AjouterJoueurlstJoueurs( joueur );

                    foreach( LignePJ ligne in lignePJs)
                    {
                        ligne.MajCmbJoueurs();
                    }

                    lignePJs[idLignePJSelectionnée].cmbJoueurSelectionnerDernierItem();



                    menuMode = 0;
                    AffichageMenuMode();
                }
            }
            else if(menuMode == 2) // Si en mode création de personnage
            {
                if (VérificationEcritureDonnées.VérificationDonnéesPersonnage(txbNomJoueur.Text, txbExpérience.Text));
                {
                    
                }
            }

            
        }

        private void btnAnnulerJoueurPerso_Click(object sender, EventArgs e)
        {
            menuMode = 0;
            AffichageMenuMode();
        }
    }
}
