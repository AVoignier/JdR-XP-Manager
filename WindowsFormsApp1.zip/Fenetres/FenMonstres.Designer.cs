﻿namespace WindowsFormsApp1
{
    partial class FenMonstres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bD_TestDataSet = new WindowsFormsApp1.BD_TestDataSet();
            this.monstreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.monstreTableAdapter = new WindowsFormsApp1.BD_TestDataSetTableAdapters.MonstreTableAdapter();
            this.monstreBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.lstMonstres = new System.Windows.Forms.ListView();
            this.Nom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Experience = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Dangerosite = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txbNom = new System.Windows.Forms.TextBox();
            this.txbExperience = new System.Windows.Forms.TextBox();
            this.txbDangerosite = new System.Windows.Forms.TextBox();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblExperience = new System.Windows.Forms.Label();
            this.lblDangerosite = new System.Windows.Forms.Label();
            this.btnAjouterValider = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnAnnulerModification = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bD_TestDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.monstreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.monstreBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // bD_TestDataSet
            // 
            this.bD_TestDataSet.DataSetName = "BD_TestDataSet";
            this.bD_TestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // monstreBindingSource
            // 
            this.monstreBindingSource.DataMember = "Monstre";
            this.monstreBindingSource.DataSource = this.bD_TestDataSet;
            // 
            // monstreTableAdapter
            // 
            this.monstreTableAdapter.ClearBeforeFill = true;
            // 
            // monstreBindingSource1
            // 
            this.monstreBindingSource1.DataMember = "Monstre";
            this.monstreBindingSource1.DataSource = this.bD_TestDataSet;
            // 
            // lstMonstres
            // 
            this.lstMonstres.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Nom,
            this.Experience,
            this.Dangerosite});
            this.lstMonstres.FullRowSelect = true;
            this.lstMonstres.HideSelection = false;
            this.lstMonstres.Location = new System.Drawing.Point(12, 12);
            this.lstMonstres.Name = "lstMonstres";
            this.lstMonstres.Size = new System.Drawing.Size(412, 331);
            this.lstMonstres.TabIndex = 0;
            this.lstMonstres.TileSize = new System.Drawing.Size(10, 10);
            this.lstMonstres.UseCompatibleStateImageBehavior = false;
            this.lstMonstres.View = System.Windows.Forms.View.Details;
            // 
            // Nom
            // 
            this.Nom.Text = "Nom";
            this.Nom.Width = 157;
            // 
            // Experience
            // 
            this.Experience.Text = "Expérience";
            this.Experience.Width = 130;
            // 
            // Dangerosite
            // 
            this.Dangerosite.Text = "Dangerosité";
            this.Dangerosite.Width = 91;
            // 
            // txbNom
            // 
            this.txbNom.Location = new System.Drawing.Point(504, 11);
            this.txbNom.Name = "txbNom";
            this.txbNom.Size = new System.Drawing.Size(132, 20);
            this.txbNom.TabIndex = 1;
            // 
            // txbExperience
            // 
            this.txbExperience.Location = new System.Drawing.Point(504, 37);
            this.txbExperience.Name = "txbExperience";
            this.txbExperience.Size = new System.Drawing.Size(132, 20);
            this.txbExperience.TabIndex = 2;
            // 
            // txbDangerosite
            // 
            this.txbDangerosite.Location = new System.Drawing.Point(504, 63);
            this.txbDangerosite.Name = "txbDangerosite";
            this.txbDangerosite.Size = new System.Drawing.Size(132, 20);
            this.txbDangerosite.TabIndex = 3;
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(469, 14);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 4;
            this.lblNom.Text = "Nom";
            // 
            // lblExperience
            // 
            this.lblExperience.AutoSize = true;
            this.lblExperience.Location = new System.Drawing.Point(438, 40);
            this.lblExperience.Name = "lblExperience";
            this.lblExperience.Size = new System.Drawing.Size(60, 13);
            this.lblExperience.TabIndex = 5;
            this.lblExperience.Text = "Expérience";
            // 
            // lblDangerosite
            // 
            this.lblDangerosite.AutoSize = true;
            this.lblDangerosite.Location = new System.Drawing.Point(434, 66);
            this.lblDangerosite.Name = "lblDangerosite";
            this.lblDangerosite.Size = new System.Drawing.Size(64, 13);
            this.lblDangerosite.TabIndex = 6;
            this.lblDangerosite.Text = "Dangerosité";
            // 
            // btnAjouterValider
            // 
            this.btnAjouterValider.Location = new System.Drawing.Point(437, 89);
            this.btnAjouterValider.Name = "btnAjouterValider";
            this.btnAjouterValider.Size = new System.Drawing.Size(199, 23);
            this.btnAjouterValider.TabIndex = 7;
            this.btnAjouterValider.Text = "AjouterValider";
            this.btnAjouterValider.UseVisualStyleBackColor = true;
            this.btnAjouterValider.Click += new System.EventHandler(this.btnAjouterValider_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Location = new System.Drawing.Point(13, 350);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(134, 31);
            this.btnSupprimer.TabIndex = 8;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(153, 350);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(134, 31);
            this.btnModifier.TabIndex = 9;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnAnnulerModification
            // 
            this.btnAnnulerModification.Location = new System.Drawing.Point(437, 118);
            this.btnAnnulerModification.Name = "btnAnnulerModification";
            this.btnAnnulerModification.Size = new System.Drawing.Size(199, 23);
            this.btnAnnulerModification.TabIndex = 11;
            this.btnAnnulerModification.Text = "Annuler Modification";
            this.btnAnnulerModification.UseVisualStyleBackColor = true;
            this.btnAnnulerModification.Visible = false;
            this.btnAnnulerModification.Click += new System.EventHandler(this.btnAnnulerModification_Click);
            // 
            // FenMonstres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 417);
            this.Controls.Add(this.btnAnnulerModification);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnAjouterValider);
            this.Controls.Add(this.lblDangerosite);
            this.Controls.Add(this.lblExperience);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.txbDangerosite);
            this.Controls.Add(this.txbExperience);
            this.Controls.Add(this.txbNom);
            this.Controls.Add(this.lstMonstres);
            this.Name = "FenMonstres";
            this.Text = "Monstres";
            ((System.ComponentModel.ISupportInitialize)(this.bD_TestDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.monstreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.monstreBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private BD_TestDataSet bD_TestDataSet;
        private System.Windows.Forms.BindingSource monstreBindingSource;
        private BD_TestDataSetTableAdapters.MonstreTableAdapter monstreTableAdapter;
        private System.Windows.Forms.BindingSource monstreBindingSource1;
        private System.Windows.Forms.ListView lstMonstres;
        private System.Windows.Forms.ColumnHeader Nom;
        private System.Windows.Forms.ColumnHeader Experience;
        private System.Windows.Forms.ColumnHeader Dangerosite;
        private System.Windows.Forms.TextBox txbNom;
        private System.Windows.Forms.TextBox txbExperience;
        private System.Windows.Forms.TextBox txbDangerosite;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblExperience;
        private System.Windows.Forms.Label lblDangerosite;
        private System.Windows.Forms.Button btnAjouterValider;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnAnnulerModification;
    }
}