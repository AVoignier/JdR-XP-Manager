﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.ClassesDonnées;
using WindowsFormsApp1.Données;

namespace WindowsFormsApp1.Fenetres.FenEquipeParamExt
{
    internal class LignePJ
    {
        protected int idLigne;
        protected static bool vivant;
        protected static FenEquipeParam fenetre;

        protected Panel pnlLigne;
        protected Button btnSupprimer;
        protected Label lblPJ;
        protected ComboBox cmbJoueurs;
        protected Button btnCréerJoueur;
        protected ComboBox cmbPersonnages;
        protected Button btnCréerPersonnage;

        private LectureDonnées lectureDonnees;
        private EcritureDonnées ecritureDonnees;
        private SuppressionDonnées suppressionDonnees;
        private ModificationDonnées modificationDonnees;

        protected static List<Joueur> joueurs;
        protected static List<Personnage> personnages;

        protected Joueur joueurSpecifique;
        protected List<Personnage> personnagesSpecifique;

        public LignePJ(FenEquipeParam fenetre, int idLigne, bool PersoVivant)
        {
            this.idLigne = idLigne;
            LignePJ.vivant = PersoVivant;
            LignePJ.fenetre = fenetre;
            InitialisationDonnées(vivant);
        }

        public LignePJ(FenEquipeParam fenetre, int idLigne, bool PersoVivant, Personnage personnage)
        {
            this.idLigne= idLigne;
            LignePJ.vivant = PersoVivant;
            LignePJ.fenetre = fenetre;
            InitialisationDonnées(vivant);
        }

        public bool CréationJoueur(string nom)
        {
            if( VérificationEcritureDonnées.VérificationDonnéesJoueur(nom))
            {
                ecritureDonnees.InsererJoueur(nom);
                MajJoueurs();

                return true;
            }

            return false;
        }

        public bool CréationPersonnage(string nom, string experience)
        {
            if (VérificationEcritureDonnées.VérificationDonnéesJoueur(nom))
            {
                ecritureDonnees.InsererJoueur(nom);
                MajJoueurs();

                return true;
            }

            return false;
        }

        public void CopierLignePJ(LignePJ lignePJ)
        {
            Panel pnlLigneCopy = lignePJ.GetPanel();
        }

        private void InitialisationDonnées( bool PersoVivant )
        {
            lectureDonnees = LectureDonnées.GetInstance();
            ecritureDonnees = EcritureDonnées.GetInstance();
            suppressionDonnees = SuppressionDonnées.GetInstance();
            modificationDonnees = ModificationDonnées.GetInstance();

            pnlLigne = new Panel();
            btnSupprimer = new Button();
            lblPJ = new Label();
            cmbJoueurs = new ComboBox();
            btnCréerJoueur = new Button();
            cmbPersonnages = new ComboBox();
            btnCréerPersonnage = new Button();

            MajJoueurs();
            MajPersonnages();

            btnSupprimer.Text = "X";
            btnSupprimer.Width = btnSupprimer.Height;
            btnSupprimer.Location = new Point(0, 0);
            btnSupprimer.Click += btnSupprimerClick;
            pnlLigne.Controls.Add(btnSupprimer);

            if( idLigne < 1)
            {
                btnSupprimer.Visible = false;
            }

            lblPJ.Text = "PJ " + (idLigne + 1);
            lblPJ.Width = 30;
            lblPJ.Location = new Point(25, 5);
            pnlLigne.Controls.Add(lblPJ);

            cmbJoueurs.Text = "Joueur";
            cmbJoueurs.Width = 130;
            cmbJoueurs.Location = new Point(60,0);
            cmbJoueurs.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbJoueurs.SelectionChangeCommitted += CmbJoueursSelectedChanged;
            pnlLigne.Controls.Add(cmbJoueurs);

            btnCréerJoueur.Text = "+";
            btnCréerJoueur.Width = btnCréerJoueur.Height;
            btnCréerJoueur.Location = new Point(200, 0);
            btnCréerJoueur.Click += btnCreerJoueurClick;
            pnlLigne.Controls.Add(btnCréerJoueur);

            cmbPersonnages.Text = "Personnage";
            cmbPersonnages.Width = 200;
            cmbPersonnages.Location = new Point(240, 0);
            cmbPersonnages.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPersonnages.SelectionChangeCommitted += CmbPersonnagesSelectedChanged;
            pnlLigne.Controls.Add(cmbPersonnages);

            btnCréerPersonnage.Text = "+";
            btnCréerPersonnage.Width = btnCréerJoueur.Height;
            btnCréerPersonnage.Location = new Point( 450,0);
            btnCréerPersonnage.Click += btnCreerPersonnageClick;
            pnlLigne.Controls.Add(btnCréerPersonnage);

        }

        public void ChangerId(int id)
        {
            idLigne = id;
            lblPJ.Text = "PJ " + (idLigne + 1);
        }

        public void MajCmbJoueurs()
        {
            //Si aucun joueur n'est déjà selectionnée

            int selectedIndex = cmbJoueurs.SelectedIndex;
            
            cmbJoueurs.Items.Clear();
            ListViewItem item;

            if (cmbPersonnages.SelectedIndex == -1)
            {
                foreach (Joueur joueur in joueurs)
                {
                    item = new ListViewItem(joueur.ToString());
                    cmbJoueurs.Items.Add(item.Text);
                }
            }
            else
            {
                item = new ListViewItem(joueurSpecifique.ToString());
                cmbJoueurs.Items.Add(item.Text);
                cmbJoueurs.SelectedIndex = 0;
            }

            if(selectedIndex != -1)
                cmbJoueurs.SelectedIndex = selectedIndex; 
        }

        public void MajCmbPersonnages()
        {
            MajPersonnages();
            cmbPersonnages.Items.Clear();
            ListViewItem item;

            if(cmbJoueurs.SelectedIndex == -1)
            {
                foreach (Personnage personnage in personnages)
                {
                    item = new ListViewItem(personnage.ToString());
                    if (!personnage.GetVivant())
                        item.ForeColor = Color.Red;

                    cmbPersonnages.Items.Add(item.Text);
                }
            }
            else
            {
                foreach (Personnage personnage in personnagesSpecifique)
                {
                    item = new ListViewItem(personnage.ToString());
                    if (!personnage.GetVivant())
                        item.ForeColor = Color.Red;

                    cmbPersonnages.Items.Add(item.Text);
                }
            }

        }

        public void MajJoueurs()
        {
            if(cmbPersonnages.SelectedIndex == -1)
            {
                joueurs = lectureDonnees.GetJoueurs();
                MajCmbJoueurs();
            }
            else
            {
                joueurSpecifique = lectureDonnees.GetJoueursParPersonnage( personnages[ cmbPersonnages.SelectedIndex ] );
                MajCmbJoueurs();
            }
            
        }

        public void MajPersonnages()
        {
            if(cmbJoueurs.SelectedIndex == -1 )
            {
                personnagesSpecifique = null;
                personnages = lectureDonnees.GetPersonnages(vivant);
            } 
            else
            {
                personnagesSpecifique = lectureDonnees.GetPersonnagesParJoueur(joueurs[cmbJoueurs.SelectedIndex], vivant);
            }
                
        }

        private void btnSupprimerClick(object sender, EventArgs e)
        {
            fenetre.BntSupprimerLignePjClick(idLigne);
        }

        private void btnCreerJoueurClick(object sender, EventArgs e)
        {
            Console.WriteLine("Nouveau Joueur " + ((Button)sender).Name);
            cmbJoueurs.SelectedIndex = -1;

            fenetre.ModeCréationJoueur(idLigne);
        }

        private void btnCreerPersonnageClick(object sender, EventArgs e)
        {
            Console.WriteLine("Nouveau Perso " + ((Button)sender).Name);
            fenetre.ModeCréationPersonnage(idLigne);
        }

        private void CmbJoueursSelectedChanged(object sender, EventArgs e)
        {
            MajCmbPersonnages();
        }

        private void CmbPersonnagesSelectedChanged(object sender, EventArgs e)
        {
            MajCmbJoueurs();
        }

        public void cmbJoueurSelectionnerDernierItem()
        {
            cmbJoueurs.SelectedIndex = joueurs.Count-1;
        }

        public Panel GetPanel()
        {
            return pnlLigne;
        }

        public void SetVivant(bool vivant)
        {
            if(LignePJ.vivant != vivant)
            {
                LignePJ.vivant = vivant;
                MajCmbPersonnages();
            }
        }

        public int GetIdLigne()
        {
            return idLigne;
        }

        public void SetId(int idLigne)
        {
            lblPJ.Text = "PJ " + (idLigne + 1);
            this.idLigne = idLigne;
        }

        public void AjouterJoueurlstJoueurs(Joueur joueur)
        {
            joueurs.Add(joueur);
        }

    }
}
