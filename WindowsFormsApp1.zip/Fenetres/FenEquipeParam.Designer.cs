﻿namespace WindowsFormsApp1
{
    partial class FenEquipeParam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomEquipe = new System.Windows.Forms.Label();
            this.tcbNomEquipe = new System.Windows.Forms.TextBox();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.grbPersonnage = new System.Windows.Forms.GroupBox();
            this.pnlPJ = new System.Windows.Forms.Panel();
            this.btnAjouterPerso = new System.Windows.Forms.Button();
            this.grbAffichageMorts = new System.Windows.Forms.GroupBox();
            this.rdbAffichageMortsNon = new System.Windows.Forms.RadioButton();
            this.rdbAffichageMortsOui = new System.Windows.Forms.RadioButton();
            this.lblNomPersonnage = new System.Windows.Forms.Label();
            this.txbNomPersonnage = new System.Windows.Forms.TextBox();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.txbExpérience = new System.Windows.Forms.TextBox();
            this.lblExpérience = new System.Windows.Forms.Label();
            this.nudNiveau = new System.Windows.Forms.NumericUpDown();
            this.lblNomJoueur = new System.Windows.Forms.Label();
            this.txbNomJoueur = new System.Windows.Forms.TextBox();
            this.btnValiderJoueurPerso = new System.Windows.Forms.Button();
            this.btnAnnulerJoueurPerso = new System.Windows.Forms.Button();
            this.grbPersonnage.SuspendLayout();
            this.grbAffichageMorts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNiveau)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNomEquipe
            // 
            this.lblNomEquipe.AutoSize = true;
            this.lblNomEquipe.Location = new System.Drawing.Point(12, 9);
            this.lblNomEquipe.Name = "lblNomEquipe";
            this.lblNomEquipe.Size = new System.Drawing.Size(64, 13);
            this.lblNomEquipe.TabIndex = 0;
            this.lblNomEquipe.Text = "Nom équipe";
            // 
            // tcbNomEquipe
            // 
            this.tcbNomEquipe.Location = new System.Drawing.Point(83, 9);
            this.tcbNomEquipe.Name = "tcbNomEquipe";
            this.tcbNomEquipe.Size = new System.Drawing.Size(173, 20);
            this.tcbNomEquipe.TabIndex = 1;
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(129, 192);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(111, 27);
            this.btnValider.TabIndex = 3;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            this.btnValider.Click += new System.EventHandler(this.BtnValider_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(246, 192);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(111, 27);
            this.btnAnnuler.TabIndex = 4;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // grbPersonnage
            // 
            this.grbPersonnage.Controls.Add(this.pnlPJ);
            this.grbPersonnage.Location = new System.Drawing.Point(12, 35);
            this.grbPersonnage.Name = "grbPersonnage";
            this.grbPersonnage.Size = new System.Drawing.Size(514, 157);
            this.grbPersonnage.TabIndex = 2;
            this.grbPersonnage.TabStop = false;
            this.grbPersonnage.Text = "Personnages";
            // 
            // pnlPJ
            // 
            this.pnlPJ.AutoScroll = true;
            this.pnlPJ.Location = new System.Drawing.Point(3, 20);
            this.pnlPJ.Name = "pnlPJ";
            this.pnlPJ.Size = new System.Drawing.Size(505, 131);
            this.pnlPJ.TabIndex = 0;
            // 
            // btnAjouterPerso
            // 
            this.btnAjouterPerso.Location = new System.Drawing.Point(12, 192);
            this.btnAjouterPerso.Name = "btnAjouterPerso";
            this.btnAjouterPerso.Size = new System.Drawing.Size(111, 27);
            this.btnAjouterPerso.TabIndex = 5;
            this.btnAjouterPerso.Text = "Ajouter Perso";
            this.btnAjouterPerso.UseVisualStyleBackColor = true;
            this.btnAjouterPerso.Click += new System.EventHandler(this.BtnAjouterPerso_Click);
            // 
            // grbAffichageMorts
            // 
            this.grbAffichageMorts.Controls.Add(this.rdbAffichageMortsNon);
            this.grbAffichageMorts.Controls.Add(this.rdbAffichageMortsOui);
            this.grbAffichageMorts.Location = new System.Drawing.Point(364, 192);
            this.grbAffichageMorts.Name = "grbAffichageMorts";
            this.grbAffichageMorts.Size = new System.Drawing.Size(162, 41);
            this.grbAffichageMorts.TabIndex = 6;
            this.grbAffichageMorts.TabStop = false;
            this.grbAffichageMorts.Text = "Afficher Personnages Morts";
            // 
            // rdbAffichageMortsNon
            // 
            this.rdbAffichageMortsNon.AutoSize = true;
            this.rdbAffichageMortsNon.Checked = true;
            this.rdbAffichageMortsNon.Location = new System.Drawing.Point(53, 18);
            this.rdbAffichageMortsNon.Name = "rdbAffichageMortsNon";
            this.rdbAffichageMortsNon.Size = new System.Drawing.Size(45, 17);
            this.rdbAffichageMortsNon.TabIndex = 1;
            this.rdbAffichageMortsNon.TabStop = true;
            this.rdbAffichageMortsNon.Text = "Non";
            this.rdbAffichageMortsNon.UseVisualStyleBackColor = true;
            // 
            // rdbAffichageMortsOui
            // 
            this.rdbAffichageMortsOui.AutoSize = true;
            this.rdbAffichageMortsOui.Location = new System.Drawing.Point(6, 18);
            this.rdbAffichageMortsOui.Name = "rdbAffichageMortsOui";
            this.rdbAffichageMortsOui.Size = new System.Drawing.Size(41, 17);
            this.rdbAffichageMortsOui.TabIndex = 0;
            this.rdbAffichageMortsOui.Text = "Oui";
            this.rdbAffichageMortsOui.UseVisualStyleBackColor = true;
            this.rdbAffichageMortsOui.CheckedChanged += new System.EventHandler(this.RdbAffichageMortsOui_CheckedChanged);
            // 
            // lblNomPersonnage
            // 
            this.lblNomPersonnage.AutoSize = true;
            this.lblNomPersonnage.Location = new System.Drawing.Point(532, 60);
            this.lblNomPersonnage.Name = "lblNomPersonnage";
            this.lblNomPersonnage.Size = new System.Drawing.Size(98, 13);
            this.lblNomPersonnage.TabIndex = 7;
            this.lblNomPersonnage.Text = "Nom Personnage : ";
            // 
            // txbNomPersonnage
            // 
            this.txbNomPersonnage.Location = new System.Drawing.Point(632, 57);
            this.txbNomPersonnage.Name = "txbNomPersonnage";
            this.txbNomPersonnage.Size = new System.Drawing.Size(154, 20);
            this.txbNomPersonnage.TabIndex = 8;
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Location = new System.Drawing.Point(532, 86);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(50, 13);
            this.lblNiveau.TabIndex = 9;
            this.lblNiveau.Text = "Niveau : ";
            // 
            // txbExpérience
            // 
            this.txbExpérience.Location = new System.Drawing.Point(702, 83);
            this.txbExpérience.Name = "txbExpérience";
            this.txbExpérience.Size = new System.Drawing.Size(84, 20);
            this.txbExpérience.TabIndex = 12;
            // 
            // lblExpérience
            // 
            this.lblExpérience.AutoSize = true;
            this.lblExpérience.Location = new System.Drawing.Point(636, 86);
            this.lblExpérience.Name = "lblExpérience";
            this.lblExpérience.Size = new System.Drawing.Size(60, 13);
            this.lblExpérience.TabIndex = 11;
            this.lblExpérience.Text = "Expérience";
            // 
            // nudNiveau
            // 
            this.nudNiveau.Location = new System.Drawing.Point(584, 84);
            this.nudNiveau.Name = "nudNiveau";
            this.nudNiveau.Size = new System.Drawing.Size(46, 20);
            this.nudNiveau.TabIndex = 13;
            this.nudNiveau.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblNomJoueur
            // 
            this.lblNomJoueur.AutoSize = true;
            this.lblNomJoueur.Location = new System.Drawing.Point(532, 35);
            this.lblNomJoueur.Name = "lblNomJoueur";
            this.lblNomJoueur.Size = new System.Drawing.Size(70, 13);
            this.lblNomJoueur.TabIndex = 14;
            this.lblNomJoueur.Text = "Nom Joueur :";
            // 
            // txbNomJoueur
            // 
            this.txbNomJoueur.Location = new System.Drawing.Point(632, 31);
            this.txbNomJoueur.Name = "txbNomJoueur";
            this.txbNomJoueur.Size = new System.Drawing.Size(154, 20);
            this.txbNomJoueur.TabIndex = 15;
            // 
            // btnValiderJoueurPerso
            // 
            this.btnValiderJoueurPerso.Location = new System.Drawing.Point(532, 109);
            this.btnValiderJoueurPerso.Name = "btnValiderJoueurPerso";
            this.btnValiderJoueurPerso.Size = new System.Drawing.Size(123, 23);
            this.btnValiderJoueurPerso.TabIndex = 16;
            this.btnValiderJoueurPerso.Text = "Valider";
            this.btnValiderJoueurPerso.UseVisualStyleBackColor = true;
            this.btnValiderJoueurPerso.Click += new System.EventHandler(this.btnValiderJoueurPerso_Click);
            // 
            // btnAnnulerJoueurPerso
            // 
            this.btnAnnulerJoueurPerso.Location = new System.Drawing.Point(661, 109);
            this.btnAnnulerJoueurPerso.Name = "btnAnnulerJoueurPerso";
            this.btnAnnulerJoueurPerso.Size = new System.Drawing.Size(125, 23);
            this.btnAnnulerJoueurPerso.TabIndex = 17;
            this.btnAnnulerJoueurPerso.Text = "Annuler";
            this.btnAnnulerJoueurPerso.UseVisualStyleBackColor = true;
            this.btnAnnulerJoueurPerso.Click += new System.EventHandler(this.btnAnnulerJoueurPerso_Click);
            // 
            // FenEquipeParam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 245);
            this.Controls.Add(this.btnAnnulerJoueurPerso);
            this.Controls.Add(this.btnValiderJoueurPerso);
            this.Controls.Add(this.txbNomJoueur);
            this.Controls.Add(this.lblNomJoueur);
            this.Controls.Add(this.nudNiveau);
            this.Controls.Add(this.txbExpérience);
            this.Controls.Add(this.lblExpérience);
            this.Controls.Add(this.lblNiveau);
            this.Controls.Add(this.txbNomPersonnage);
            this.Controls.Add(this.lblNomPersonnage);
            this.Controls.Add(this.grbAffichageMorts);
            this.Controls.Add(this.btnAjouterPerso);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.grbPersonnage);
            this.Controls.Add(this.tcbNomEquipe);
            this.Controls.Add(this.lblNomEquipe);
            this.Name = "FenEquipeParam";
            this.Text = "EquipeParam";
            this.grbPersonnage.ResumeLayout(false);
            this.grbAffichageMorts.ResumeLayout(false);
            this.grbAffichageMorts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNiveau)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomEquipe;
        private System.Windows.Forms.TextBox tcbNomEquipe;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.GroupBox grbPersonnage;
        private System.Windows.Forms.Panel pnlPJ;
        private System.Windows.Forms.Button btnAjouterPerso;
        private System.Windows.Forms.GroupBox grbAffichageMorts;
        private System.Windows.Forms.RadioButton rdbAffichageMortsNon;
        private System.Windows.Forms.RadioButton rdbAffichageMortsOui;
        private System.Windows.Forms.Label lblNomPersonnage;
        private System.Windows.Forms.TextBox txbNomPersonnage;
        private System.Windows.Forms.Label lblNiveau;
        private System.Windows.Forms.TextBox txbExpérience;
        private System.Windows.Forms.Label lblExpérience;
        private System.Windows.Forms.NumericUpDown nudNiveau;
        private System.Windows.Forms.Label lblNomJoueur;
        private System.Windows.Forms.TextBox txbNomJoueur;
        private System.Windows.Forms.Button btnValiderJoueurPerso;
        private System.Windows.Forms.Button btnAnnulerJoueurPerso;
    }
}