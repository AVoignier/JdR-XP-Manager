﻿namespace WindowsFormsApp1
{
    partial class FenPersonnages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbEquipe = new System.Windows.Forms.ComboBox();
            this.lblEquipe = new System.Windows.Forms.Label();
            this.lstPersonnages = new System.Windows.Forms.ListView();
            this.Nom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Niveau = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Experience = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.brnAfficherPersonnagesMorts = new System.Windows.Forms.GroupBox();
            this.rdbMortNon = new System.Windows.Forms.RadioButton();
            this.rdbMortOui = new System.Windows.Forms.RadioButton();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnModifier = new System.Windows.Forms.Button();
            this.grbModification = new System.Windows.Forms.GroupBox();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblXP = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.chbVivant = new System.Windows.Forms.CheckBox();
            this.brnAfficherPersonnagesMorts.SuspendLayout();
            this.grbModification.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEquipe
            // 
            this.cmbEquipe.FormattingEnabled = true;
            this.cmbEquipe.Location = new System.Drawing.Point(59, 10);
            this.cmbEquipe.Name = "cmbEquipe";
            this.cmbEquipe.Size = new System.Drawing.Size(268, 21);
            this.cmbEquipe.TabIndex = 0;
            this.cmbEquipe.SelectedIndexChanged += new System.EventHandler(this.cmbEquipe_SelectedIndexChanged);
            // 
            // lblEquipe
            // 
            this.lblEquipe.AutoSize = true;
            this.lblEquipe.Location = new System.Drawing.Point(13, 13);
            this.lblEquipe.Name = "lblEquipe";
            this.lblEquipe.Size = new System.Drawing.Size(40, 13);
            this.lblEquipe.TabIndex = 1;
            this.lblEquipe.Text = "Equipe";
            // 
            // lstPersonnages
            // 
            this.lstPersonnages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Nom,
            this.Niveau,
            this.Experience});
            this.lstPersonnages.FullRowSelect = true;
            this.lstPersonnages.HideSelection = false;
            this.lstPersonnages.Location = new System.Drawing.Point(16, 38);
            this.lstPersonnages.Name = "lstPersonnages";
            this.lstPersonnages.Size = new System.Drawing.Size(311, 229);
            this.lstPersonnages.TabIndex = 2;
            this.lstPersonnages.UseCompatibleStateImageBehavior = false;
            this.lstPersonnages.View = System.Windows.Forms.View.Details;
            this.lstPersonnages.SelectedIndexChanged += new System.EventHandler(this.lstPersonnages_SelectedIndexChanged);
            // 
            // Nom
            // 
            this.Nom.Text = "Nom";
            this.Nom.Width = 93;
            // 
            // Niveau
            // 
            this.Niveau.Text = "Niveau";
            // 
            // Experience
            // 
            this.Experience.Text = "Expérience";
            this.Experience.Width = 87;
            // 
            // brnAfficherPersonnagesMorts
            // 
            this.brnAfficherPersonnagesMorts.Controls.Add(this.rdbMortNon);
            this.brnAfficherPersonnagesMorts.Controls.Add(this.rdbMortOui);
            this.brnAfficherPersonnagesMorts.Location = new System.Drawing.Point(333, 10);
            this.brnAfficherPersonnagesMorts.Name = "brnAfficherPersonnagesMorts";
            this.brnAfficherPersonnagesMorts.Size = new System.Drawing.Size(238, 46);
            this.brnAfficherPersonnagesMorts.TabIndex = 3;
            this.brnAfficherPersonnagesMorts.TabStop = false;
            this.brnAfficherPersonnagesMorts.Text = "Afficher personnages morts";
            // 
            // rdbMortNon
            // 
            this.rdbMortNon.AutoSize = true;
            this.rdbMortNon.Checked = true;
            this.rdbMortNon.Location = new System.Drawing.Point(54, 19);
            this.rdbMortNon.Name = "rdbMortNon";
            this.rdbMortNon.Size = new System.Drawing.Size(45, 17);
            this.rdbMortNon.TabIndex = 4;
            this.rdbMortNon.TabStop = true;
            this.rdbMortNon.Text = "Non";
            this.rdbMortNon.UseVisualStyleBackColor = true;
            this.rdbMortNon.CheckedChanged += new System.EventHandler(this.rdbMortNon_CheckedChanged);
            // 
            // rdbMortOui
            // 
            this.rdbMortOui.AutoSize = true;
            this.rdbMortOui.Location = new System.Drawing.Point(7, 20);
            this.rdbMortOui.Name = "rdbMortOui";
            this.rdbMortOui.Size = new System.Drawing.Size(41, 17);
            this.rdbMortOui.TabIndex = 0;
            this.rdbMortOui.TabStop = true;
            this.rdbMortOui.Text = "Oui";
            this.rdbMortOui.UseVisualStyleBackColor = true;
            this.rdbMortOui.CheckedChanged += new System.EventHandler(this.rdbMortOui_CheckedChanged);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(121, 277);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(99, 23);
            this.btnAnnuler.TabIndex = 5;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(16, 277);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(99, 23);
            this.btnValider.TabIndex = 7;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(226, 277);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(99, 23);
            this.btnModifier.TabIndex = 8;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            // 
            // grbModification
            // 
            this.grbModification.Controls.Add(this.chbVivant);
            this.grbModification.Controls.Add(this.numericUpDown1);
            this.grbModification.Controls.Add(this.textBox1);
            this.grbModification.Controls.Add(this.lblXP);
            this.grbModification.Controls.Add(this.lblNom);
            this.grbModification.Location = new System.Drawing.Point(334, 63);
            this.grbModification.Name = "grbModification";
            this.grbModification.Size = new System.Drawing.Size(237, 237);
            this.grbModification.TabIndex = 9;
            this.grbModification.TabStop = false;
            this.grbModification.Text = "Modification Personnage";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(7, 22);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 10;
            this.lblNom.Text = "Nom";
            // 
            // lblXP
            // 
            this.lblXP.AutoSize = true;
            this.lblXP.Location = new System.Drawing.Point(7, 48);
            this.lblXP.Name = "lblXP";
            this.lblXP.Size = new System.Drawing.Size(60, 13);
            this.lblXP.TabIndex = 12;
            this.lblXP.Text = "Expérience";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(72, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(159, 20);
            this.textBox1.TabIndex = 13;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(73, 46);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(158, 20);
            this.numericUpDown1.TabIndex = 14;
            // 
            // chbVivant
            // 
            this.chbVivant.AutoSize = true;
            this.chbVivant.Location = new System.Drawing.Point(6, 73);
            this.chbVivant.Name = "chbVivant";
            this.chbVivant.Size = new System.Drawing.Size(56, 17);
            this.chbVivant.TabIndex = 15;
            this.chbVivant.Text = "Vivant";
            this.chbVivant.UseVisualStyleBackColor = true;
            // 
            // FenPersonnages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grbModification);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.brnAfficherPersonnagesMorts);
            this.Controls.Add(this.lstPersonnages);
            this.Controls.Add(this.lblEquipe);
            this.Controls.Add(this.cmbEquipe);
            this.Name = "FenPersonnages";
            this.Text = "FenPersonnages";
            this.brnAfficherPersonnagesMorts.ResumeLayout(false);
            this.brnAfficherPersonnagesMorts.PerformLayout();
            this.grbModification.ResumeLayout(false);
            this.grbModification.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbEquipe;
        private System.Windows.Forms.Label lblEquipe;
        private System.Windows.Forms.ListView lstPersonnages;
        private System.Windows.Forms.ColumnHeader Nom;
        private System.Windows.Forms.ColumnHeader Experience;
        private System.Windows.Forms.GroupBox brnAfficherPersonnagesMorts;
        private System.Windows.Forms.RadioButton rdbMortNon;
        private System.Windows.Forms.RadioButton rdbMortOui;
        private System.Windows.Forms.ColumnHeader Niveau;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.GroupBox grbModification;
        private System.Windows.Forms.CheckBox chbVivant;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblXP;
        private System.Windows.Forms.Label lblNom;
    }
}