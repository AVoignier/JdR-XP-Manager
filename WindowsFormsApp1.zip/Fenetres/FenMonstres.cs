﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp1.Données;

namespace WindowsFormsApp1
{
    public partial class FenMonstres : Form
    {
        private LectureDonnées lectureDonnees;
        private EcritureDonnées ecritureDonnees;
        private SuppressionDonnées suppressionDonnees;
        private ModificationDonnées modificationDonnees;

        private List<Monstre> monstres;

        private int menuMode;
        // 0 -> Mode par defaut
        // 1 -> Création Monstre en cours
        // 2 -> Modification Monstre
        // 3 -> Suppression Monstre en cours

        public FenMonstres()
        {
            InitializeComponent();

            lectureDonnees = LectureDonnées.GetInstance();
            ecritureDonnees = EcritureDonnées.GetInstance();
            suppressionDonnees = SuppressionDonnées.GetInstance();
            modificationDonnees = ModificationDonnées.GetInstance();

            monstres = new List<Monstre>();

            menuMode = 0;
            AffichageMenuMode();

            MajMonstres();

        }

        private void AffichageMenuMode()
        {
            if (menuMode == 0) // Mode par defaut
            {
                txbNom.Text = "";
                txbExperience.Text = "";
                txbDangerosite.Text = "";

                lblNom.Visible = true;
                txbNom.Visible = true;
                lblExperience.Visible = true;
                txbExperience.Visible = true;
                lblDangerosite.Visible = true;
                txbDangerosite.Visible = true;

                btnAjouterValider.Text = "Créer Monstre";
                btnAjouterValider.Visible = true;
                btnAnnulerModification.Visible = false;

                btnSupprimer.Visible = true;
                btnModifier.Visible = true;

                lstMonstres.Enabled = true;

            }
            else if (menuMode == 1) // Mode Création Monstre en cours
            {
                lstMonstres.Enabled = false;
            }
            else if (menuMode == 2) // Mode Modification Monstre
            {
                btnAjouterValider.Text = "Valider Modification";
                btnAjouterValider.Visible = true;
                btnSupprimer.Visible = false;
                btnModifier.Visible = false;
                btnAnnulerModification.Visible = true;
                lstMonstres.Enabled = false;

                btnSupprimer.Visible=false;
                btnModifier.Visible=false;

                btnAnnulerModification.Visible = true;


            }
            else if(menuMode == 3) // Mode Suppréssion Monstre en cours
            {
                lstMonstres.Enabled=false;
            }
        }

        private void MajMonstres()
        {
            monstres.Clear();
            monstres = lectureDonnees.GetMonstres();

            MajLstMonstres();
        }

        private void MajLstMonstres()
        {
            lstMonstres.Items.Clear();

            ListViewItem item;

            foreach (Monstre monstre in monstres)
            {
                item = new ListViewItem(monstre.GetNom());
                item.SubItems.Add(monstre.GetExperience().ToString());
                item.SubItems.Add(monstre.GetDangerosite().ToString());

                lstMonstres.Items.Add(item);
            }

        }

        private void btnAjouterValider_Click(object sender, EventArgs e)
        {
            if(menuMode == 0)
            {
                if (VérificationEcritureDonnées.VérificationDonnéesMonstre(txbNom.Text, txbDangerosite.Text, txbExperience.Text))
                {
                    string nom = txbNom.Text;
                    int experience;
                    int.TryParse(txbExperience.Text, out experience);
                    double dangerosite;
                    double.TryParse(txbDangerosite.Text, out dangerosite);
                    bool personnalise = true;

                    ecritureDonnees.InsererMonstre( nom, experience,dangerosite, personnalise);

                    MajMonstres();

                    txbNom.Clear();
                    txbExperience.Clear();
                    txbDangerosite.Clear();
                }

            }
            if( menuMode == 2) // mode modification monstre
            {
                if (VérificationEcritureDonnées.VérificationDonnéesMonstreAvecException(txbNom.Text, txbDangerosite.Text, txbExperience.Text, monstres[ lstMonstres.SelectedIndices[0] ] ))
                {
                    string nom = txbNom.Text;
                    int experience;
                    int.TryParse(txbExperience.Text, out experience);
                    double dangerosite;
                    double.TryParse(txbDangerosite.Text, out dangerosite);
                    bool personnalise = true;

                    modificationDonnees.ModificationMonstre(monstres[lstMonstres.SelectedIndices[0]], nom, dangerosite, experience, personnalise);

                    MajMonstres();

                    txbNom.Clear();
                    txbExperience.Clear();
                    txbDangerosite.Clear();

                    menuMode = 0;
                    AffichageMenuMode();
                }
            }


        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (lstMonstres.SelectedIndices.Count == 0)
            {
                string msg = "Vous devez selectionner un monstre";
                MessageBox.Show(msg, "Supprimer Monstre", MessageBoxButtons.OK);
            }
            else if (lstMonstres.SelectedItems.Count == 1)
            {
                string nom = monstres[lstMonstres.SelectedIndices[0]].GetNom();
                string msg = "Etes vous sur de vouloir supprimer le monstre : " + nom;

                if (MessageBox.Show(msg, "Suppression Monstre", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    suppressionDonnees.SupprimerMonstre(monstres[lstMonstres.SelectedIndices[0]]);

                    MajMonstres();
                }
            }
            else if (lstMonstres.SelectedItems.Count > 1)
            {
                string msg = "Etes vous sur de vouloir supprimer ces " + lstMonstres.SelectedItems.Count.ToString() + " monstres ? ";

                if (MessageBox.Show(msg, "Suppression Monstres", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    List<Monstre> monstresSupprimer = new List<Monstre>();

                    foreach (int index in lstMonstres.SelectedIndices)
                    {
                        monstresSupprimer.Add(monstres[index]);
                    }

                    suppressionDonnees.SupprimerMonstres(monstresSupprimer);

                    MajMonstres();
                }
            }

        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (lstMonstres.SelectedIndices.Count == 0)
            {
                string msg = "Vous devez selectionner un monstre";
                MessageBox.Show(msg, "Modifier Monstre", MessageBoxButtons.OK);
            }
            else if (lstMonstres.SelectedItems.Count == 1)
            {
                txbNom.Text = monstres[ lstMonstres.SelectedIndices[0] ].GetNom();
                txbExperience.Text = monstres[lstMonstres.SelectedIndices[0]].GetExperience().ToString();
                txbDangerosite.Text = monstres[lstMonstres.SelectedIndices[0]].GetDangerosite().ToString();

                menuMode = 2;
                AffichageMenuMode();

            }
            else
            {
                string msg = "Vous ne pouvez modifier qu'un monstre à la fois";
                MessageBox.Show(msg, "Modifier Monstre", MessageBoxButtons.OK);
            }
        }

        private void btnAnnulerModification_Click(object sender, EventArgs e)
        {
            menuMode = 0;
            AffichageMenuMode();
        }
    }
}
