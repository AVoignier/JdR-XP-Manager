﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp1
{
    internal class Monstre
    {
        protected int id;
        protected string nom;
        protected double dangerosite;
        protected int experience;
        protected bool personnalise;

        public Monstre(int id, string nom, double dangerosite, int experience, bool personnalise)
        {
            this.id = id;
            this.nom = nom;
            this.dangerosite = dangerosite;
            this.experience = experience;
            this.personnalise = personnalise;
        }

        public int GetId()
        {
            return id;
        }

        public string GetNom()
        {
            return nom;
        }

        public double GetDangerosite()
        {
            return dangerosite;
        }

        public int GetExperience()
        {
            return experience;
        }

        public bool GetPersonnalise()
        {
            return personnalise;
        }


    }
}
