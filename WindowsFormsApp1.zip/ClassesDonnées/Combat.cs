﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp1.ClassesDonnées
{
    internal class Combat
    {
        protected int id;
        protected List<Monstre> Monstres;
        protected List<int> quantité;

    }
}
